package com.example.ruchira.boilermakermatch;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.util.Log;
import android.support.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;


import java.util.ArrayList;
import java.util.HashMap;


public class UserMatching extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_matching);

        final Bundle extras = getIntent().getExtras();


        FirebaseFirestore db = FirebaseFirestore.getInstance();
        final CollectionReference usersRef = db.collection("users");
        String name;
        String phone;
        String place;

        name = extras != null ? extras.getString("nameTransfer") : "nothing passed in";
        phone = extras != null ? extras.getString("phoneTransfer") : "nothing passed in";
        place = extras != null ? extras.getString("placeTransfer") : "nothing passed in";

        HashMap<String, String> user = new HashMap<>();
        user.put("name", name);
        user.put("phone", phone);
        user.put("place", place);
        usersRef.document(phone).set(user);
        usersRef.add(user)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Log.d("FIRE", "DocumentSnapshot written with ID: " + documentReference.getId());
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w("FIRE", "Error adding document", e);
                    }
                });

        /*db.collection("users")
                .whereEqualTo("place", place)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.d("FIRE",document.getId() + " => " + document.getData());
                            }
                        } else {
                            Log.d("FIRE", "Error getting documents: ", task.getException());
                        }
                    }
                });


        Query matchingUsers = usersRef.whereEqualTo("place", "Off Campus");
        matchingUsers.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                for(QueryDocumentSnapshot task.getResult())
            }
        })*/


        //Log.e("debug", matchingUsers);







    }
}

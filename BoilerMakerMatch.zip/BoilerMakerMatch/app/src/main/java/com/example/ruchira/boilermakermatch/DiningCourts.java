package com.example.ruchira.boilermakermatch;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;

public class DiningCourts extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dining_courts);

        final Button foodButton = (Button) findViewById(R.id.foodButtonId);
        final Button exerciseButton = (Button)findViewById(R.id.exerciseButtonId);

        foodButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(DiningCourts.this, FoodOptions.class));
            }
        });
    }
}

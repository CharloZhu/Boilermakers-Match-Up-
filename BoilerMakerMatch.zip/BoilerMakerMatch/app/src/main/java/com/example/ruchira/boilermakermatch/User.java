package com.example.ruchira.boilermakermatch;

public class User {
    String name;
    String phone;
    String place;

    public User(String name, String phone, String place) {
        this.name = name;
        this.phone = phone;
        this.place = place;
    }
}

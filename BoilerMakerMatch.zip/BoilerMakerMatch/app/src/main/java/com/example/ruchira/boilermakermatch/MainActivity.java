package com.example.ruchira.boilermakermatch;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button sendButton = (Button) findViewById(R.id.sendButtonId);
        final EditText nameEditText = (EditText) findViewById(R.id.nameTextBoxId);
        final EditText phoneEditText = (EditText) findViewById(R.id.phoneTextBoxId);


        FirebaseFirestore db = FirebaseFirestore.getInstance();

        final CollectionReference usersRef = db.collection("users");


        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = nameEditText.getText().toString();
                String phone = phoneEditText.getText().toString();

                final int SECONDARY_ACTIVITY_REQUEST_CODE = 0;
                Intent i = new Intent(getApplicationContext(), typeChoice.class );
                i.putExtra("nameTransfer", name);
                i.putExtra("phoneTransfer", phone);
                //startActivityForResult(i, SECONDARY_ACTIVITY_REQUEST_CODE);

                /*HashMap<String, String> user = new HashMap<>();
                user.put("name", name);
                user.put("phone", phone);
                usersRef.add(user)
                        .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                            @Override
                            public void onSuccess(DocumentReference documentReference) {
                                Log.d("FIRE", "DocumentSnapshot written with ID: " + documentReference.getId());
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.w("FIRE", "Error adding document", e);
                            }
                        });*/

                startActivity(i);
            }
        });

    }
}

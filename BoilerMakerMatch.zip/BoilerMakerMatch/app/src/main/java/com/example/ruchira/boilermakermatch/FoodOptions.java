package com.example.ruchira.boilermakermatch;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.util.Log;
import android.support.annotation.NonNull;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.HashMap;

public class FoodOptions extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_options);

        final Button onCampusButton = (Button) findViewById(R.id.onCampusId);
        final Button offCampusButton = (Button)findViewById(R.id.offCampusId);
        final Button anythingButton = (Button) findViewById(R.id.anythingId);

        final Bundle extras = getIntent().getExtras();


        FirebaseFirestore db = FirebaseFirestore.getInstance();
        final CollectionReference usersRef = db.collection("users");

        onCampusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(FoodOptions.this, OnCampusOptions.class));
            }
        });

        offCampusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String place = "Off Campus";
                String name;
                String phone;

                name = extras != null ? extras.getString("nameTransfer") : "nothing passed in";
                phone = extras != null ? extras.getString("phoneTransfer") : "nothing passed in";

                final int SECONDARY_ACTIVITY_REQUEST_CODE = 0;
                Intent i = new Intent(getApplicationContext(), UserMatching.class );
                i.putExtra("nameTransfer", name);
                i.putExtra("phoneTransfer", phone);
                i.putExtra("placeTransfer", place);

                startActivity(i);
            }
        });
    }
}

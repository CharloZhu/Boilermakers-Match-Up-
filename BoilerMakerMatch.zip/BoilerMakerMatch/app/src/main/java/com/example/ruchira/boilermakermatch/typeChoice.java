package com.example.ruchira.boilermakermatch;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class typeChoice extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_type_choice);
        String name;
        String phone;
        final Bundle extras = getIntent().getExtras();

        name = extras != null ? extras.getString("nameTransfer") : "nothing passed in";
        phone = extras != null ? extras.getString("phoneTransfer") : "nothing passed in";

        Log.e("debug", name);

        final int SECONDARY_ACTIVITY_REQUEST_CODE = 0;
        Intent i = new Intent(getApplicationContext(), FoodOptions.class );
        i.putExtra("nameTransfer", name);
        i.putExtra("phoneTransfer", phone);

                final Button foodButton = (Button) findViewById(R.id.foodButtonId);
                final Button exerciseButton = (Button)findViewById(R.id.exerciseButtonId);

                foodButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        startActivity(i);
                    }
                });


    }
}

